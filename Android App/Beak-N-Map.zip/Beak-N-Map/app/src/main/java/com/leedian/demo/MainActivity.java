package com.leedian.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;



public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    private TextView tvShowData;
    private TextView tvShowDataTime;
    public Button btnGetData;
    private Chronometer timer;
    private Button btnSettings;
    private ImageView Img;


    /**
     * 把控件的初始化放在这个方法里面
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Img = (ImageView) findViewById(R.id.imageView);
        timer = (Chronometer) findViewById(R.id.timer);
        btnGetData = (Button) findViewById(R.id.btn_get_data);
        tvShowData = (TextView) findViewById(R.id.tv_show_data);
        tvShowDataTime = (TextView) findViewById(R.id.tv_show_data_time);
        btnGetData.setOnClickListener(this);
        btnSettings = (Button) findViewById(R.id.settings);
        btnSettings.setOnClickListener(this);

//        savekey();

   // public static Object get(Context context, String spName, String key, Object defaultObject) {
    }

    /**
     * 控件的点击事件
     * @param view
     */
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_get_data:
                getdata();
                timer.setBase(SystemClock.elapsedRealtime());//计时器清零
                int hour = (int) ((SystemClock.elapsedRealtime() - timer.getBase()) / 1000 / 60);
                timer.setFormat("0" + String.valueOf(hour) + ":%s");
                timer.start();
                break;
            case R.id.settings:
                startActivity(new Intent(MainActivity.this, MySettingActivity.class));
            default:

        }

    }

    /**
     * 使用okhttp 进行网络请求
     * 各种请求方式参考(http://blog.csdn.net/hzl9966/article/details/51434716)
     */
    public void getdata() {

        String url = "http://192.168.1.69:8080/data";

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(new Callback() {


            @Override
            public void onFailure(Call call, IOException e) {
                Log.i(TAG, "onFailure: " + e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                MyData myData = new Gson().fromJson(response.body().charStream(), MyData.class);

                double current = myData.getChip1().getRaw_time() ;
                long Newcurrent = (long) ridDecimal(current*1000);

                Date date = new Date(Newcurrent);
                DateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
                format.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
                String formatted = format.format(date);

                SwitchCheck(myData,formatted);

            }
        });

    }



    private String  showChipData;
    public void SwitchCheck( MyData myData ,  String formatted ) {
        showChipData="";
        boolean chip1 = PreferenceUtil.getInstance(MainActivity.this).getBoolean("chip1", false);
        boolean chip2 = PreferenceUtil.getInstance(MainActivity.this).getBoolean("chip2", false);
        boolean chip3 = PreferenceUtil.getInstance(MainActivity.this).getBoolean("chip3", false);


        MyData.Chip1Bean chip11 = myData.getChip1();
        MyData.Chip2Bean chip21 = myData.getChip2();
        MyData.Chip3Bean chip13 = myData.getChip3();



        if (chip1 == true) {
            if (chip11!=null){
                showChipData+=chip11.toString();
            }else {
                showChipData+="No Data";
            }

        }

        if (chip2 == true) {
            if (chip21!=null){
                showChipData+=chip21.toString();
            }else {
                showChipData+="\n"+"\n"+"No Data";
            }
        }

        if (chip3 == true) {

            if (chip13!=null){
                showChipData+=chip13.toString();
            }else {
                showChipData+="\n"+"\n"+"No Data";
            }
        }


        if (chip1==false&&chip2==false&&chip3==false){
            showChipData="Please select a chip to display.";
        }

        setDataUI(showChipData,formatted + "");

    }

    private double ridDecimal(double a) {
        DecimalFormat df = new DecimalFormat(".");
        a = Double.valueOf(df.format(a));
        return a;
    }



    public void setDataUI(final String str1,final String str2){

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                tvShowData.setText(str1);
                tvShowDataTime.setText(str2);
                Picasso.with(MainActivity.this).load("http://192.168.1.69:8080/location.png").memoryPolicy(MemoryPolicy.NO_CACHE).into(Img);
            }
        });
    }}


