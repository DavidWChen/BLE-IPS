package com.leedian.demo;

/**
 * Created by leedian on 17-8-2.
 */

public class Globals {

        public static Object mydata;
        public static Object mydata2;
        public static Object mydata3;
        public static String name1;
        public static String name2;
        public static String name3;
}
